var firebaseConfig = {
    apiKey: "AIzaSyCvkVbSsY1tTvIDx6_K6XKylIE-3zjV0VU",
    authDomain: "automasipro-9983e.firebaseapp.com",
    databaseURL: "https://automasipro-9983e-default-rtdb.asia-southeast1.firebasedatabase.app",
    projectId: "automasipro-9983e",
    storageBucket: "automasipro-9983e.appspot.com",
    messagingSenderId: "133594665147",
    appId: "1:133594665147:web:e97f49941bd1ae9ecb599e"
};
firebase.initializeApp(firebaseConfig);